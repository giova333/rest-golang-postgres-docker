create function pg_sleep_until(timestamp with time zone) returns void
    strict
    parallel safe
    cost 1
    language sql
as
$$
select pg_catalog.pg_sleep(extract(epoch from $1) operator(pg_catalog.-) extract(epoch from pg_catalog.clock_timestamp()))
$$;

comment on function pg_sleep_until(timestamp with time zone) is 'sleep until the specified time';

alter function pg_sleep_until(timestamp with time zone) owner to admin;

